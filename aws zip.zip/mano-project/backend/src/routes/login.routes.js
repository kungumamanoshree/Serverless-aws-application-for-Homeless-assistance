const express = require('express');
const db = require('../database');
const bcrypt = require('bcrypt');

const loginRoute = express.Router();


loginRoute.post('/login', (req, res) => {
    const { email, password } = req.body;
    const query = `SELECT * FROM users WHERE email = ?`;

    db.get(query, [email], async(err, user) => {
        if(err) {
            return res.status(400).json({
                message: err,
                status: 0
            });
        }

        if(!user) {
            return res.status(400).json({
                message: 'user not found',
                status: 0
            });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if(!passwordMatch) {
            return res.status(401).json({
                message: "Invalid password",
                status: 0
            });
        }
        res.status(200).json({
            message: 'Login successful',
            status: 1
        });
    });
});

module.exports = loginRoute;
