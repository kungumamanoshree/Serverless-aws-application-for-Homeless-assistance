const express = require('express');
const db = require('../database');

const postsRoute = express.Router();

postsRoute.get('/posts', (req, res) => {
    
});


module.exports = postsRoute;
