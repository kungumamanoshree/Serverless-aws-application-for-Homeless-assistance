const express = require('express');
const db = require('../database');
const bcrypt = require('bcrypt');  

const registerRoute = express.Router();


registerRoute.post('/register', (req, res) => {
    const {name, email, password} = req.body;

    if(!name || !email || !password) {
        return res.status(400).json({
            message: "Invalid name or email or password",
            status: 0
        });
    }

    db.get(`SELECT * FROM users WHERE email = ?`, [email], async (err, row) => {
        if(err) {
            return res.status(404).json({
                message: err.message,
                status: 0
            });
        }

        if(row) {
            return res.status(400).json({
                message: 'user already exists with email: ' + email,
                status: 0
            })
        }

        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            const queryInsertUser = `INSERT INTO users (name, email, password) VALUES (?, ?, ?)`;

            db.run(queryInsertUser, [name, email, hashedPassword], function(err) {
                if(err) {
                    return res.status(500).json({
                        message: err.message,
                        status: 0
                    });
                }
                return res.status(201).json({
                    message: 'user registered successfully',
                    userId: this.lastID,
                    status: 1
                });
            })
        } catch(err) {
            console.log('Error in register api: ' + err)
            return res.status(500).json({
                message: err,
                status: 0
            });
        }
    })

});

module.exports = registerRoute;
